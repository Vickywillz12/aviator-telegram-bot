import os
import sqlite3
import statistics
from datetime import datetime, timezone

from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes

DB = os.getenv("AVIATOR_DB", "aviator.db")
TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")

def get_conn():
    conn = sqlite3.connect(DB)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS rounds (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            multiplier REAL NOT NULL,
            created_at TEXT NOT NULL
        )
    """)
    conn.commit()
    return conn

def add_round(multiplier):
    conn = get_conn()
    conn.execute(
        "INSERT INTO rounds(multiplier, created_at) VALUES (?, ?)",
        (float(multiplier), datetime.now(timezone.utc).isoformat())
    )
    conn.commit()
    conn.close()

def get_rounds(limit=1000):
    conn = get_conn()
    rows = conn.execute(
        "SELECT multiplier FROM rounds ORDER BY id DESC LIMIT ?", (limit,)
    ).fetchall()
    conn.close()
    return [r[0] for r in rows]

def count_rounds():
    conn = get_conn()
    n = conn.execute("SELECT COUNT(*) FROM rounds").fetchone()[0]
    conn.close()
    return n

def analyze(values):
    n = len(values)
    return {
        "n": n,
        "avg": statistics.mean(values),
        "median": statistics.median(values),
        "min": min(values),
        "max": max(values),
        "under150": sum(x < 1.5 for x in values),
        "between150_199": sum(1.5 <= x < 2 for x in values),
        "between2_499": sum(2 <= x < 5 for x in values),
        "between5_999": sum(5 <= x < 10 for x in values),
        "over10": sum(x >= 10 for x in values),
    }

def pct(x, n):
    return x / n * 100

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "🚀 Aviator Analyzer v1 is online!\n\n"
        "Commands:\n"
        "/add 1.72 — save a multiplier\n"
        "/stats — analyze the latest 1,000 rounds\n"
        "/last — show the latest 20 rounds\n"
        "/count — show total stored rounds\n\n"
        "This bot performs statistical analysis; it does not guarantee the next result."
    )

async def add(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text("Usage: /add 1.72")
        return
    try:
        value = float(context.args[0].lower().replace("x", ""))
        if value < 1:
            raise ValueError
        add_round(value)
        await update.message.reply_text(f"✅ Saved {value:.2f}x")
    except ValueError:
        await update.message.reply_text("❌ Invalid multiplier. Example: /add 2.37")

async def stats_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    values = get_rounds(1000)
    if not values:
        await update.message.reply_text("No rounds stored yet. Use /add 1.50")
        return

    s = analyze(values)
    n = s["n"]
    text = (
        f"📊 Latest {n} rounds\n\n"
        f"Average: {s['avg']:.2f}x\n"
        f"Median: {s['median']:.2f}x\n"
        f"Lowest: {s['min']:.2f}x\n"
        f"Highest: {s['max']:.2f}x\n\n"
        f"<1.50x: {pct(s['under150'], n):.1f}%\n"
        f"1.50–1.99x: {pct(s['between150_199'], n):.1f}%\n"
        f"2–4.99x: {pct(s['between2_499'], n):.1f}%\n"
        f"5–9.99x: {pct(s['between5_999'], n):.1f}%\n"
        f"10x+: {pct(s['over10'], n):.1f}%"
    )
    await update.message.reply_text(text)

async def last(update: Update, context: ContextTypes.DEFAULT_TYPE):
    values = get_rounds(20)
    if not values:
        await update.message.reply_text("No rounds stored yet.")
        return
    await update.message.reply_text(
        "🧾 Latest rounds:\n" +
        "\n".join(f"{i+1}. {v:.2f}x" for i, v in enumerate(values))
    )

async def count(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(f"📦 Stored rounds: {count_rounds()}")

def main():
    if not TOKEN:
        raise RuntimeError("TELEGRAM_BOT_TOKEN is not set.")

    get_conn().close()

    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("add", add))
    app.add_handler(CommandHandler("stats", stats_cmd))
    app.add_handler(CommandHandler("last", last))
    app.add_handler(CommandHandler("count", count))

    print("Aviator Telegram Analyzer is running.")
    app.run_polling(drop_pending_updates=True)

if __name__ == "__main__":
    main()

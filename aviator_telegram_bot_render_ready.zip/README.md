# Aviator Telegram Analyzer — Render Ready

## No-code deployment

This project is configured as a Render **Background Worker**. Render supports continuously running background workers for long-running processes. 

### 1. Protect your Telegram token

The token previously posted in chat should be revoked in BotFather. Generate a fresh token and keep it private.

### 2. Put this project on GitHub

Create a new GitHub repository and upload these files:
- `bot.py`
- `requirements.txt`
- `render.yaml`
- `README.md`

You do not need to edit any code.

### 3. Deploy on Render

In Render:
1. Create an account/sign in.
2. Connect GitHub.
3. Create a new Blueprint/Project from the repository.
4. Render reads `render.yaml`.
5. When asked for `TELEGRAM_BOT_TOKEN`, paste your NEW token.
6. Deploy.

The build command is `pip install -r requirements.txt` and the worker starts with `python bot.py`.

### 4. Test in Telegram

Open your bot and send:

`/start`

Then:

`/add 1.72`

`/stats`

`/last`

`/count`

## Important limitation

This version still requires the multiplier to be supplied with `/add`. It does not scrape or bypass a betting site.

The next version can add a legitimate accessible data-ingestion source and backtesting. It should not be represented as a guaranteed prediction system.
